package selenium.demoblaze.gocomet;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Demo {
	
    //global variable
	public static WebDriver driver=null;
	
		 public static void main(String[] args)  throws InterruptedException
		 {
		     
				System.setProperty("webdriver.chrome.driver","C:\\Users\\Shivam Verma\\eclipse-workspace\\selenium_java\\dd\\chromedriver.exe");
				driver = new ChromeDriver();
		    	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);		
		    	
		    	//open web application
		    	driver.navigate().to("https://www.demoblaze.com/");
		    	//this will maximixe window screen
		    	driver.manage().window().maximize();
		    	String title = driver.getTitle();
		    	
		    	//Checking if title is matching
		    	if(title.equalsIgnoreCase("DemoBlaze"))
		    		System.out.println("Title Matched");
		    	else
		    		System.out.println(title);
		    	
		    	//to locate a web element
		    	String tagname=" ";
		    	tagname = driver.findElement(By.cssSelector("#cat")).getText();
		    	System.out.println(tagname);
		    	
		    	//Clicking on phone in categories
		    	WebElement phone = driver.findElement(By.cssSelector("#itemc"));
		    	Actions actions = new Actions(driver);
		    	actions.moveToElement(phone);
		    	actions.click();
		    	actions.perform();
		    	Thread.sleep(2000);
		    	
		    	
		    	//finding Samsung s6 product element
		    	WebElement sam = driver.findElement(By.cssSelector("#tbodyid > div:nth-child(1) > div > a > img"));
		    	actions.moveToElement(sam);
		    	//clicking on samsung s6 product and will show us the product detail
		    	actions.click();
		    	actions.perform();
		    	Thread.sleep(2000);
		    	
		    	//finding Add to Cart button on the product detail page
		    	WebElement cat = driver.findElement(By.cssSelector("#tbodyid > div.row > div > a"));
		    	actions.moveToElement(cat);
		    	//clicking on Add to cart button to add product in our cart
		    	actions.click();
		    	actions.perform();
		    	
		    	//finding cart page
		    	WebElement cart = driver.findElement(By.cssSelector("#cartur"));
		    	actions.moveToElement(cart);
		    	//clicking on cart that will shows us products in cart
		    	actions.click();
		    	actions.perform();
		    	Thread.sleep(2000);
		    	
		    	
		    	 
		    	//finding place order button to buy product
		    	WebElement place = driver.findElement(By.cssSelector("#page-wrapper > div > div.col-lg-1 > button"));
		    	actions.moveToElement(place);
		    	//clicking on Place order button to buy product
		    	actions.click();
		    	actions.perform();
		    	Thread.sleep(2000);
		    	
		    	//Entering values in name field
		    	WebElement name = driver.findElement(By.cssSelector("#name"));
		    	name.sendKeys("Shivam Verma");
		    	Thread.sleep(2000);
		    	
		    	//Entering values in country field
		    	WebElement country = driver.findElement(By.cssSelector("#country"));
		    	country.sendKeys("India");
		    	Thread.sleep(2000);
		    	
		    	//Entering values in city field
		    	WebElement city = driver.findElement(By.cssSelector("#city"));
		    	city.sendKeys("Mumbai");
		    	Thread.sleep(2000);
		    	
		    	//Entering values in card field
		    	WebElement card = driver.findElement(By.cssSelector("#card"));
		    	card.sendKeys("4545 7878 8989 2323");
		    	Thread.sleep(2000);
		    	
		    	//Entering values in month field
		    	WebElement month = driver.findElement(By.cssSelector("#month"));
		    	month.sendKeys("21/22");
		    	Thread.sleep(2000);
		    	
		    	//Entering values in year field
		    	WebElement year = driver.findElement(By.cssSelector("#year"));
		    	year.sendKeys("1996");
		    	Thread.sleep(2000);
		    	
		    	//Finally clicking on purchase button to buy product 
		    	WebElement purchase = driver.findElement(By.cssSelector("#orderModal > div > div > div.modal-footer > button.btn.btn-primary"));
		    	actions.moveToElement(purchase);
		    	actions.click();
		    	actions.perform();
		    	Thread.sleep(2000);
		    	
		    	
		    	//clicking on ok button that will redirect us to home page 
		    	WebElement ok = driver.findElement(By.cssSelector("body > div.sweet-alert.showSweetAlert.visible > div.sa-button-container > div > button"));
		    	actions.moveToElement(ok);
		    	actions.click();
		    	actions.perform();
		    	Thread.sleep(2000);	    	
		    	
	} 

}
